import React from 'react';
import NavBar from './NavBar';
function HomePages() {
 return (
 <div>
 <NavBar />
 <h1>Welcome to Our Website!</h1>
 <p>This is some content for the HomePages.</p>
 </div>
 );
}
export default HomePages;
