import React from 'react';
import NavBar from './NavBar';
function Chatbots() {
 return (
 <div>
 <NavBar />
 <h2>Chatbots</h2>
 <p>This is the Chatbots page.</p>
 {/* Add Chatbots logic here */}
 </div>
 );
};
export default Chatbots;
