import React from 'react';
function NavBar() {
 return (
 <nav>
 <ul>
 <li><a href="/">Home</a></li>
 <li><a href="./PersonalDetails">Calculator</a></li>
 <li><a href="/Chatbots">Chatbots</a></li>
 <li><a href="/faq">Faq</a></li>
 </ul>
 </nav>
 );
}
export default NavBar;
